# tkinter_doc_printer
This project repo is shwing you the ways to print your files /tkinter application data through your printer.
There are five files for five methods of doing the same.
method1.py ------ method5.py

Watch full description and use of code from here.:
https://youtu.be/W9w-lYnJhVI

method3 example screenshot:
![image](https://user-images.githubusercontent.com/41276382/148669218-bc5cf081-c15c-4c09-becf-dfa65b673249.png)

printed in hard copy:
![image](https://user-images.githubusercontent.com/41276382/148669619-b547e473-fa0b-4d98-bd3c-3ff1631289c8.png)

